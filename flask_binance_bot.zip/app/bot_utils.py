import requests
import time
from binance.client import Client
from .config import API_KEY, API_SECRET, TELEGRAM_TOKEN, TELEGRAM_CHAT_ID

client = Client(API_KEY, API_SECRET)

def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg}
    requests.post(url, json=payload)

def log_trade(msg):
    with open("logs/trade_log.txt", "a") as f:
        f.write(f"{time.ctime()} - {msg}\n")

def place_order(symbol, side, qty, tp=None, sl=None):
    try:
        order = client.futures_create_order(
            symbol=symbol,
            side=side,
            type='MARKET',
            quantity=qty
        )
        msg = f"{side} order placed: {qty} {symbol}"
        if tp or sl:
            msg += f" | TP: {tp} | SL: {sl}"
        send_telegram(msg)
        log_trade(msg)
        return order
    except Exception as e:
        send_telegram(f"Order Failed: {e}")
        log_trade(f"Order Failed: {e}")
        return None