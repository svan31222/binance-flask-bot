from flask import Flask, request, jsonify, render_template
from .bot_utils import place_order
from .config import WEBHOOK_SECRET, TRADE_SYMBOL, QUANTITY
import pandas as pd
import os

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/chart-data")
def chart_data():
    if not os.path.exists("logs/trade_log.txt"):
        return jsonify({"timestamps": [], "pnl": []})
    with open("logs/trade_log.txt") as f:
        lines = f.readlines()
    timestamps = []
    pnl = []
    balance = 0
    for line in lines:
        if "order placed" in line:
            timestamps.append(line.split(" - ")[0])
            if "SELL" in line:
                balance += 50
            elif "BUY" in line:
                balance -= 50
            pnl.append(balance)
    return jsonify({"timestamps": timestamps, "pnl": pnl})

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.json
    if data.get("secret") != WEBHOOK_SECRET:
        return jsonify({"error": "Unauthorized"}), 403

    signal = data.get("signal")
    if signal == "BUY":
        place_order(TRADE_SYMBOL, "BUY", QUANTITY, tp=100, sl=50)
    elif signal == "SELL":
        place_order(TRADE_SYMBOL, "SELL", QUANTITY, tp=100, sl=50)
    elif signal == "EXIT":
        place_order(TRADE_SYMBOL, "SELL", QUANTITY)
    elif signal == "REDUCE":
        place_order(TRADE_SYMBOL, "SELL", QUANTITY * 0.5)
    else:
        return jsonify({"error": "Unknown signal"}), 400

    return jsonify({"status": "order executed"})